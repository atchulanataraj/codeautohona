$(document).ready(function() {
var currentLat,currentLong,srcc,destt,destLat,destLong;
var markers= [];
var autolist;

 $("#UserLogin").click(function(){
 			                            	  
 		                            	 var uname=$("#LoginUserName").val(); 
 			                            	 var pwd=$("#LoginUserPwd").val(); 
 			                            	 var cmt=$("#user_comment").val(); 
 			                            	 var rate=$("#user_rate").val(); 
 			                            	 var auto_id=$("#active_auto_id").val(); 
 			                            	 if(uname != "" && pwd != ""){ 
 			                            	 
 			                            		 $.ajax({ 
 			       								   
 			       				url: "http://autohonatest.meximas.com/service/loginstatus.php?uname="+uname+"&pwd="+pwd+"&cmt="+cmt+"&rate="+rate+"&autoId="+auto_id, 
 			       								  dataType:"json", 
 			       								  success:function(data){ 
 			       								   if(data.status=="success"){ 
 			       									   alert("success"); 
 			       								   }else{ 
 			       									   alert("failed"); 
 			       								   } 
 			       																   
 			       								  }, 
 			       								  error:function(){ 
 			       									 
 			       								  } 
 			       						}); 
 			                            		  
 			                            	 } 
 			                            	  
 			                             }); 

					$("#regUser").click(function() {
						var fname=$("#regFirstName").val();
						var lname=$("#regLastName").val();
						var email=$("#regEmail").val();
						var pwd=$("#regPwd").val();
						var phone=$("#regMobile").val();
						function validateEmail()
						{
						   var emailID = email;
						   atpos = emailID.indexOf("@");
						   dotpos = emailID.lastIndexOf(".");
						   if (atpos < 1 || ( dotpos - atpos < 2 )) 
						   {
						       alert("Please enter correct email ID")
						       document.myForm.EMail.focus() ;
						       return false;
						   }
						   return( true );
						}
						function PhoneNumber()
						{
						  var PhoneID = phone;
						  var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
						  if(PhoneID.match(phoneno))
						        {
								
						      return true;
						        }
						      else
						        {
						        alert("Not a valid Phone Number");
						        return false;
						        }
						}


						if(fname.length<20&&fname.length!=""&&fname.length>4)
						{
						if(lname.length<20&&lname.length!=""&&lname.length>4)
						{
						  var ret = validateEmail();
						  if( ret == true )
						  {
						     if(pwd.length<20&&pwd.length!=""&&pwd.length>8)
							 {

							 var rec = PhoneNumber();
							 	 
							 if(rec==true)
							 {
							       $.ajax({
								  
								  url: "http://autohonatest.meximas.com/service/getAutoData.php?type=register&firstName="+fname+"&lastName="+lname+"&pwd="+pwd+"&phone="+phone+"&email="+email,
								  dataType:"json",
								  success:function(){
									//  alert("saved successfully");
						saveUserReview();
						           $("#lean_overlay").fadeOut(200);
						          //var modal_id = $(this).attr("href");

						                $(".popupContainer").fadeOut(200);
																  
								  },
								  error:function(){
									 // alert("data input error");
								  }
						});
							 }
							 }
							 else
							 {
							 alert("password must be 8 - 12 characters!!");
							 }
						  }
						}
						else{
						alert("enter correct Second name should not exceed 20 characters")
						}
						}
						else{
						alert("enter correct First name should not exceed 20 characters")
						}



									});

					function setRoute() {
						if (sourcestore != '' && destinationstore != '') {

							calcRoute();
						} else {
							$("#message").text("please enter the google adress bars.... source and destination").fadeIn(1000).fadeOut(3000);
							$("#pac-input1").focus();

						}
					}
					function calcRoute() {

						var start = sourcestore;
						var end = destinationstore;

						var request = {
							origin : start,
							destination : end,
							travelMode : google.maps.TravelMode.DRIVING
						};
						directionsService.route(request, function(response,
								status) {
							if (status == google.maps.DirectionsStatus.OK) {
								directionsDisplay.setDirections(response);
								 codeAddress();
								//getAutoData();
							}
						});
						
					}
					function codeAddress() {
                        if(geocoder==null)
						    geocoder = new google.maps.Geocoder();
						var src_address = document.getElementById("pac-input1").value;
						var dest_address = document.getElementById("pac-input2").value;
						geocoder.geocode({ 'address': dest_address},
									 function(results, status) {
								
										if (status == google.maps.GeocoderStatus.OK) 
										{
							                destLat=results[0].geometry.location.lat();
											destLong=results[0].geometry.location.lng();
										}
											else 
											{
												 	$("#message").html("Geocode was not successful for the following reason: " + status).trigger("pagecreate").fadeIn();
											}
									});
						geocoder.geocode({ 'address': src_address},
									 function(results, status) {
								
							                if (status == google.maps.GeocoderStatus.OK) {
							                currentLat=results[0].geometry.location.lat();
											currentLong=results[0].geometry.location.lng();
												srcc  = "" + $("#pac-input1").val();
												destt = "" + $("#pac-input2").val();
												getAutoData();
											        
								               }
											 else {
												 	
												 	$("#message").html("Geocode was not successful for the following reason: " + status).trigger("pagecreate").fadeIn();
											 		}
									});
									
									
					}//codeAddress()
					function getAutoData() {
					rightopen();
						
					$(".black_overlay").fadeIn(200);
						$("#message").html("Loading...<h3><img src='img/loader.gif' /></h3>").trigger("pagecreate").fadeIn();
						/*
						 * $.blockUI({ message : '<h3><img
						 * src="img/loader.gif" /> Just a moment...</h3>', css : {
						 * border : '0px' } });
						 */
						 
						 var urll = "http://autohonatest.meximas.com/service/getAutoData.php?type=autolist&currentLat="+currentLat+"&currentLng="+currentLong+"&source="+srcc+"&destination="+destt+"&destLat="+destLat+"&destLng="+destLong;
						 $.ajax({
									url : urll,
									cache : false,
									dataType : "json",
									success : function(dataAll) {
										$(".black_overlay").fadeOut(200);
										$("#message").text("Loading...").fadeOut(2000);
										$("#autolistDiv").html("");
										var data = dataAll[0].data;
										console.log(dataAll);
										var faree = dataAll[1].fare;
										autolist =data;
										window.location.autolist = data;
										data.sort(function(a, b) {
											return parseFloat(a.dist)
													- parseFloat(b.dist)
										});

										$.each(data,function(index, value) {

															$("#autolistDiv")
																	.append(
																			"<a><div class='auto' id='"+value.autoid+"'>Id:"
																					+ value.autoid
																					+ "<br>Name:"
																					+ value.drivername
																					+ "<br>Dist:"
																					+ value.dist/1000 +"KM"
																					+ "<br>Fare:"
																					+ faree
																					+ "<div class='display-item'></div><button id='"
																					+ value.autoid
																					+ "' index='"
																					+ index
																					+ "' onclick=\"popupDiv('"+value.autoid+"');\" class='orange' >Details</button></div></a>");
														});
										pointingAutos();
									},
									error : function(error) {
										$(".black_overlay").fadeOut(200);
										$("#message").text("Error in getting data......").fadeIn().fadeOut(3000);
							
									
									}
								});

					}

					var pointingAutos = function() {

						var autolis = autolist;

						var marker;
						markers = new Array();
						
						// Add the markers and infowindows to the map
						for (var i = 0; i < autolis.length; i++) {
						//alert("placing");
							marker = new google.maps.Marker({
								position : new google.maps.LatLng(
										autolis[i].latitude,
										autolis[i].longitude),
								icon : 'img/auto.png',
								map : map
							});

							markers.push(marker);
							google.maps.event
									.addListener(
											marker,
											'click',
											(function(marker, i) {
												return function() {
													infowindow
															.setContent("Auto<br>DriverName:"
																	+ autolis[i].drivername
																	+ "<br>Rating"
																	+ autolis[i].rating
																	+ "<br>Distance"
																	+ autolis[i].dist
																	+ "mtr<br/><span onclick=\"popupDiv('"+autolis[i].autoid+"');\" sytle='cursor: pointer;'><b>More....</b></span>");													infowindow
															.open(map, marker);
												}
											})(marker, i));

						}
					}
					var infowindow = new google.maps.InfoWindow({
					// maxWidth: 160
					});
					$("#roundtrip").click(function() {
					olah();
					if(document.getElementById("pac-input1").value&&document.getElementById("pac-input2").value!='')
					{
					document.getElementById('srcre').innerHTML= document.getElementById("pac-input1").value;
					document.getElementById('dscre').innerHTML= document.getElementById("pac-input2").value;			
					}
					});
					
					$("#showRighte").click(function() {
					if(document.getElementById("pac-input1").value&&document.getElementById("pac-input2").value!='')
					{
					//alert(markers.length+"goiing to loop");
					document.getElementById('srcre').innerHTML= document.getElementById("pac-input1").value;
					document.getElementById('dscre').innerHTML= document.getElementById("pac-input2").value;
					}					
																if(markers.length!=0)
																{
																 
																for (var i = 0; i < markers.length; i++) {
																//alert()
																markers[i].setMap(null);
																}
																markers = [];
																}
			
					//alert(markers.length);
			
										var src = document.getElementById("pac-input1").value;
										var dst = document.getElementById("pac-input2").value;

										// console.log(document.getElementById("pac-input1").value);
										if (src == ""|| src.localeCompare("enter source") == 0) {
											$("#message").text(
													"Enter Source...").fadeIn(
													1000).fadeOut(3000);
											$("#pac-input1").focus();
											return;

										}

										if (dst == "" || dst.localeCompare("enter destination") == 0) {
											$("#message").text(
													"Enter Destination...")
													.fadeIn(1000).fadeOut(3000);
											$("#pac-input2").focus();

											return;
										}
										if (src != "" && dst != "") {
											
											setRoute();
										}
										// codeAddress();
										// getAutoData();

									});

					var town1, town2, sourcestore = '', destinationstore = '';
					var directionsDisplay;
					var directionsService;
					var map;
					var geocoder;
					function initialize() {
						headerDown();
						bottomUp();
						//rightopen();
						geocoder = new google.maps.Geocoder();
						directionsService = new google.maps.DirectionsService();

						var mapOptions = {
							center : new google.maps.LatLng(17.385044,
									78.486671),
							zoom : 13,
							disableDefaultUI : true
						};
						directionsDisplay = new google.maps.DirectionsRenderer();
						map = new google.maps.Map(document
								.getElementById('map-canvas'), mapOptions);
						directionsDisplay.setMap(map);

						var input = (document.getElementById('pac-input1'));
						var options = {
  componentRestrictions: {country: 'ind'}
};
var options1 = {
  componentRestrictions: {country: 'ind'}
};
						var button_search = (document
								.getElementById('find_location'));

						var types = document.getElementById('type-selector');

						var autocomplete = new google.maps.places.Autocomplete(
								input, options);
						autocomplete.bindTo('bounds', map);

						google.maps.event
								.addListener(
										autocomplete,
										'place_changed',
										function() {
											var place = autocomplete.getPlace();

											var address = '';
											if (place.address_components) {
												address = [
														(place.address_components[0]
																&& place.address_components[0].short_name || ''),
														(place.address_components[1]
																&& place.address_components[1].short_name || ''),
														(place.address_components[2]
																&& place.address_components[2].short_name || '') ]
														.join(',');
											}
											sourcestore = address;
										});

						var input1 = (document.getElementById('pac-input2'));

						var types1 = document.getElementById('type-selector');

						var autocomplete1 = new google.maps.places.Autocomplete(
								input1, options1);
						autocomplete.bindTo('bounds', map);
						google.maps.event
								.addListener(
										autocomplete1,
										'place_changed',
										function() {
											var place1 = autocomplete1
													.getPlace();
											var address1 = '';
											if (place1.address_components) {
												address1 = [
														(place1.address_components[0]
																&& place1.address_components[0].short_name || ''),
														(place1.address_components[1]
																&& place1.address_components[1].short_name || ''),
														(place1.address_components[2]
																&& place1.address_components[2].short_name || '') ]
														.join(',');
											}
											destinationstore = address1;
										});

						// --------------map loaded end -----------//
						// --------search and pointing ----------//

						

					}
					google.maps.event.addDomListener(window, 'load',initialize);
$("#bookbut").click(function() {
var dateandtime = $("#dateandtim").val();
var d = (new Date(dateandtime)).getTime();
var dateis = "2015-04-21 02:02:02";
var srcloc, destloc, roundtrip;
srcloc = $("#srcre").text();
destloc = $("#dscre").text();
var tripflag=$('#isrtrip').is(':checked') ? "Y" : "N" ;
var urll = "http://autohonatest.meximas.com/service/setAppointment.php?userId=49&fromLoc="+srcloc+"&toLoc="+destloc+"&dAt="+dateis+"&tripFlag="+tripflag;
console.log(urll);
						 $.ajax({
									url : urll,
									cache : false,
									dataType : "json",
									success : function(dataAll) {
									alert(dataAll.message)
									},
									error : function(error) {}
								});
});
});