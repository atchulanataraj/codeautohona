<?php

header("Access-Control-Allow-Origin: *");
require_once('json.php');
$mysql_host = "mysql.hostinger.in";
$mysql_database = "u494114538_yah";
$mysql_user = "u494114538_yah";
$mysql_password = "harank123";


$conn = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die(mysql_error());
mysql_select_db($mysql_database,$conn) or die(mysql_error());

$sql= "SELECT * FROM `attendance` ORDER BY attend_date,employeeId asc";
$result= mysql_query($sql);

echo "<div id='dvData'>";
echo "<table>";
echo "<tr>";
echo "     <th>Date </th>";
echo "        <th>AH0012</th>";
echo "        <th>AH0013</th>";
echo "        <th>AH0014</th>";
echo "        <th>AH0015</th>";
echo "    </tr>";

while($post = mysql_fetch_assoc($result))
						{
                                                      $temp="<tr><td>".$post['attend_date']."</td><td>".$post['status']."</td>";
                                                      $post = mysql_fetch_assoc($result);
					               $temp=$temp."<td>".$post['status']."</td>";
                                                            $post = mysql_fetch_assoc($result);
					               $temp=$temp."<td>".$post['status']."</td>";
                                                      $post = mysql_fetch_assoc($result);
					               $temp=$temp."<td>".$post['status']."</td></tr>";

                                                        echo $temp;

						}
echo "</table>";


	?>	