<?php
 header("Access-Control-Allow-Origin: *");
require_once('json.php');

$mysql_host = "mysql.hostinger.in";
$mysql_database = "u494114538_harnk";
$mysql_user = "u494114538_harnk";
$mysql_password = "harank123";

$conn = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die(mysql_error());
mysql_select_db($mysql_database,$conn) or die(mysql_error());



		
$posts=array();

$responsesData=array();
$responses=array();
 
if($_GET['type']=='getUrls'){
$sql="SELECT ad_url FROM `autoads` WHERE auto_id=".$_GET['autoId']." and ad_status=1 ORDER BY ad_date desc";

$result=mysql_query($sql);

if(mysql_num_rows($result) <> $_GET['adCount']){
					
						while($post = mysql_fetch_assoc($result))
						{
					
							$responses[]=$post;
					
						}
					
					}

$responsesData[]=array('data'=>$responses);

}


else
   $responsesData[]=array('data'=>'invalid url');
   

$responsesData[]=array('status'=>'1');


echo json_encode($responsesData);

?>

